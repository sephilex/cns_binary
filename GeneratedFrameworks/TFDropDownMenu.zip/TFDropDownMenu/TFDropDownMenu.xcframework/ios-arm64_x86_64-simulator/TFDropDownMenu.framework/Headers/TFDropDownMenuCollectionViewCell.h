//
//  TFDropDownMenuCollectionViewCell.h
//  TFDropDownMenu
//
//  Created by jiangyunfeng on 2018/6/30.
//  Copyright © 2018年 jiangyunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TFDropDownMenuCollectionViewCell : UICollectionViewCell
@property (nonatomic, strong) UILabel *titleLabel;
@end

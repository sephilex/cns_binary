//
//  TZProgressView.h
//  TZImagePickerController
//
//  Created by ttouch on 2016/12/6.
//  Copyright © 2016年 谭真. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TZProgressView : UIView

@property (nonatomic, assign) double progress;

@end

//
//  TZVideoEditedPreviewController.h
//  TZImagePickerController
//
//  Created by 肖兰月 on 2021/5/29.
//  Copyright © 2021 谭真. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TZVideoEditedPreviewController : UIViewController
@property (nonatomic, copy) NSURL *videoURL;
@end

NS_ASSUME_NONNULL_END

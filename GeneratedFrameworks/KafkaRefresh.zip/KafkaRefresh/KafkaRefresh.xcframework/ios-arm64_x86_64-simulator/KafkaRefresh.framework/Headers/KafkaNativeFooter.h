/**
 * Copyright (c) 2016-present, K.
 * All rights reserved.
 *
 * Email:xorshine@icloud.com
 *
 * This source code is licensed under the MIT license.
 */

#import "KafkaFootRefreshControl.h"

@interface KafkaNativeFooter : KafkaFootRefreshControl

@end
